


function  [out, seed1_new, seed2_new, seed3_new] = taus(seed1, seed2, seed3)

    b0 = bitshift(bitxor(bitshift(seed1, 13, 'uint32'), seed1), -19, 'uint32');

    seed1_new = bitxor(bitshift(bitand(seed1, 4294967294), 12, 'uint32'), b0);

    b1 = bitshift(bitxor(bitshift(seed2, 2, 'uint32'), seed2), -25, 'uint32');

    seed2_new = bitxor(bitshift(bitand(seed2, 4294967288), 4, 'uint32'), b1);

    b2 = bitshift(bitxor(bitshift(seed3, 3, 'uint32'), seed3), -11, 'uint32');

    seed3_new = bitxor(bitshift(bitand(seed3, 4294967280), 17, 'uint32'), b2);

    out = bitxor(bitxor(seed1, seed2), seed3);

end