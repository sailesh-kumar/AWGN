function [out] = formatter(a0)

    a00 = (dec2bin(a0)) - '0';

%fprintf('before flip'); display(dec2hex(a00));

    a00 = fliplr(a00);

%fprintf('after flip'); display(dec2hex(a00));

    len = length(a00);

    for i = 1:32-len

        a00(len+i)= 0;

    end

%fprintf('after adding 0s flip '); display(dec2hex(a00));

    out = fliplr(a00);

end