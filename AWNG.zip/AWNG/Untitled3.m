


seed1 = hex2dec('22b1ffff');%randi(2^32)

seed2 = hex2dec('aeadffff');%randi(2^32)

seed3 = hex2dec('6559ffff');%randi(2^32)

seed4 = hex2dec('a74dffff');%randi(2^32)

seed5 = hex2dec('cdf7ffff');%randi(2^32)

seed6 = hex2dec('b94dffff');%randi(2^32)




outfile = fopen('awgn_new.txt','w');




[a0, s0, s1, s2,] = taus(seed1, seed2, seed3);

[a1, s4, s5, s6,] = taus(seed4, seed5, seed6);




for j = 1:10000

    [a0, s0, s1, s2] = taus(s0, s1, s2);

    [a1, s4, s5, s6] = taus(s4, s5, s6);

     

    a00 = formatter(a0);

    a11 = formatter(a1);

    

    for i = 1:16

        a00(32+i) = a11(i);

    end

    u0 = char(a00+'0');

    u0=bin2dec(u0);

    for i = 1:16

        a111(i) = a11(i+16);

    end

    u1 = char(a111+'0');

    u1 = bin2dec(u1);

    

    e = -2*log(u0);

    f = sqrt(e);

    g0 = sin(2*pi*u1);

    g1 = cos(2*pi*u1);

    x0 = f*g0;

    x1 = f*g1;

    

    fprintf(outfile,'%20.20x \n',sqrt(real(x0)*real(x0)+imag(x0)*imag(x0)));

end

fclose(outfile);
